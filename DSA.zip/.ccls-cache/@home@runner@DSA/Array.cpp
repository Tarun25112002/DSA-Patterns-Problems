// #include <iostream>
// using namespace std;
// int main()
// {
//     int x = 0 ;
//     int arr[x];
//     cout << "Enter length of array :";
//     cin >> x;
//     for (int i = 0; i <= x; i++)
//     {
//         arr[i];
//     }
// }