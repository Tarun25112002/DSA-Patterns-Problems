
// #include <iostream>
// using namespace std;

// int main() {
//   int number;
//   cout << "Enter Your Number For Pattern Printing: ";
//   cin >> number;
//   for(int i = 0 ; i < number ; i++){
//     for(int j = 0 ; j<number-i-1 ; j++){
//       cout << " ";
//     }
//     for(int k = 0 ; k<i+1 ; k++){
//       cout << " * ";
//     }
//     cout << endl;
//   }
      
//   }
    