#include <cmath>
#include <iostream>
using namespace std;
int Binarytodecimal(int x) {
  int digit = 0;
  for (int i = 0; x != 0; i++) {
    int bit = x % 10;
    digit = digit + bit * pow(2, i);
    x = x / 10;
  }
  return digit;
}
int main() {
  int x;
  cout << "Enter a number: ";
  cin >> x;
  cout << Binarytodecimal(x);
}