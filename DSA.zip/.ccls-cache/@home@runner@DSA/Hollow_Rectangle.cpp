// #include <iostream>
// using namespace std;
// int main() {
//   int x;
//   cout << "Enter a number for your pattern: ";
//   cin >> x;
//   for (int i = 1; i <= x; i++) {
//     if (i == 1 || i == x) {
//       for (int j = 1; j <= x; j++)
//         cout << " * ";
//      cout << endl; 
//     } else {
//       for (int k = 1; k <= x; k++) {
//         if (k == 1 || k == x) {
//           cout << " * ";
//         } else
//           cout << "   ";
//       }
//       cout << endl;
//     }
//   }
//   return 0;
// }
