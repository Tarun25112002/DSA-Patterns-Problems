// #include <cmath>
// #include <iostream>
// using namespace std;

// // int binaryfunction1(int x) {
// //   int binarynumber = 0;
// //   for (int i = 0; x > 0; i++) {
// //     int bit = x % 2;
// //     binarynumber += bit * pow(10, i);
// //     x = x / 2;
// //   }

// //   return binarynumber;
// // }
// int binaryfunction2(int x){
//   int binarynumber = 0;
//   for(int i = 0 ; x>0 ; i++){
//     int bit = x&1;
//     binarynumber = binarynumber+ bit* pow(10, i);
//     x = x>>1;
//   }
//   return binarynumber;
// }

// int main() {
//   int x;
//   cout << "Enter a number for conversion: ";
//   cin >> x;

//   int binaryno = binaryfunction2(x);

//   cout << "Binary representation: " << binaryno << endl;

//   return 0;
// }
