// #include <iostream>
// using namespace std;

// int main() {
//   int number;
//   cout << "Enter Your Number For Patttern Printing: ";
//   cin >> number;
//   for (int i = 0; i < number; i++) {
//     for (int j = 0; j <= i; j++){
//       cout << " * ";}
//     cout << endl;
//   }

//   return 0;
// }